package com.zz.flink.cdc;

public class MultiTableTest {

    public static void main(String[] args) {
//        DebeziumDeserializationSchema<String> schema = new StringDebeziumDeserializationSchema();
//        Map<String, String> map;
//        Configuration config = Configuration.fromMap(map);
//        MySqlParallelSource<String> source = new MySqlParallelSource<>(schema,config);
    }
}
